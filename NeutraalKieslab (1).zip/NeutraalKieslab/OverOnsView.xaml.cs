﻿using System.Windows.Controls;

namespace NeutraalKieslab;

public partial class OverOnsView : UserControl
{
    public OverOnsView()
    {
        InitializeComponent();
    }
}