﻿using System;

namespace NeutraalKieslab
{
    public enum AnswerType
    {
        Eens,
        Neutraal,
        Oneens,
        Skip
    }
}