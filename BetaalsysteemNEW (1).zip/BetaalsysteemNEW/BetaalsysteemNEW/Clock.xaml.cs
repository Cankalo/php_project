﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace BetaalsysteemNEW
{
    /// <summary>
    /// Interaction logic for Clock.xaml
    /// </summary>
    public partial class Clock : Window
    {
        private bool timeEditable = false;
        private DispatcherTimer timer;
        private int hours;
        private int minutes;
        private int seconds;

        public Clock()
        {
            InitializeComponent();
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += Timer_Tick;
        }

        private void btSetTime_Click(object sender, RoutedEventArgs e)
        {
            if (timeEditable == false)
            {
                timeEditable = true;
                btSetTime.Content = "Start Clock";
                tbHours.IsReadOnly = false;
                tbMinutes.IsReadOnly = false;
                tbSeconds.IsReadOnly = false;
                timer.Stop();
            }
            else
            {
                timeEditable = false;
                btSetTime.Content = "(Re)Set Time";
                tbHours.IsReadOnly = true;
                tbMinutes.IsReadOnly = true;
                tbSeconds.IsReadOnly = true;

                // Parse the time from the textboxes
                if (int.TryParse(tbHours.Text, out hours) &&
                    int.TryParse(tbMinutes.Text, out minutes) &&
                    int.TryParse(tbSeconds.Text, out seconds))
                {
                    timer.Start();
                }
                else
                {
                    MessageBox.Show("Invalid Format");
                }
            }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            // Update time
            seconds++;
            if (seconds >= 60)
            {
                seconds = 0;
                minutes++;
                if (minutes >= 60)
                {
                    minutes = 0;
                    hours++;
                    if (hours >= 24)
                    {
                        hours = 0;
                    }
                }
            }

            // Update textboxes
            tbHours.Text = hours.ToString("D2");
            tbMinutes.Text = minutes.ToString("D2");
            tbSeconds.Text = seconds.ToString("D2");
        }

        private void FormatTextbox(TextBox textBox, int maxValue)
        {
            if (int.TryParse(textBox.Text, out int value))
            {
                if (value > maxValue)
                {
                    value = maxValue;
                }
                textBox.Text = value.ToString("D2");
                textBox.CaretIndex = textBox.Text.Length; // Move caret to end
            }
        }

        private void tbHours_TextChanged(object sender, TextChangedEventArgs e)
        {
            FormatTextbox(tbHours, 23); // Max value 23
        }

        private void tbMinutes_TextChanged(object sender, TextChangedEventArgs e)
        {
            FormatTextbox(tbMinutes, 59); // Max value 59
        }

        private void tbSeconds_TextChanged(object sender, TextChangedEventArgs e)
        {
            FormatTextbox(tbSeconds, 59); // Max value 59
        }
    }
}
