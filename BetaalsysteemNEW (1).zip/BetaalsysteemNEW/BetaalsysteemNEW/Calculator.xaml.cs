﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BetaalsysteemNEW
{
    /// <summary>
    /// Interaction logic for Calculator.xaml
    /// </summary>
    public partial class Calculator : Window
    {
        private double _currentValue = 0;
        private double _storedValue = 0;
        private string _currentOperation = string.Empty;
        private bool _isNewEntry = true;

        public Calculator()
        {
            InitializeComponent();
        }

        private void NumberButton_Click(object sender, RoutedEventArgs e)
        {
            // Add number to calculation string
            Button button = sender as Button;
            if (_isNewEntry)
            {
                Display.Text = button.Content.ToString();
                _isNewEntry = false;
            }
            else
            {
                Display.Text += button.Content.ToString();
            }
        }

        private void PiButton_Click(object sender, RoutedEventArgs e)
        {
            // Add pi as number to calculation string
            if (_isNewEntry)
            {
                Display.Text = Math.PI.ToString();
                _isNewEntry = false;
            }
            else
            {
                Display.Text += Math.PI.ToString();
            }
        }

        private void OperationButton_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            // checks the last character on the display
            // if the display is not empty (Length != 0) return the last character of the string
            // otherwise return an empty string
            string lastChar = Display.Text.Length > 0 ? Display.Text[^1].ToString() : string.Empty;
            // Check if the last chararcter is an operator
            if (lastChar == "+" || lastChar == "-" || lastChar == "*" || lastChar == "/")
            {
                // Removes the last inputted character (to remove/ignore a double operator)
                Display.Text = Display.Text.Substring(0, Display.Text.Length - 1) + button.Content.ToString();
            }
            else
            {
                if (!_isNewEntry)
                {
                    //if not a double operator process the operator
                    if (double.TryParse(Display.Text, out _storedValue))
                    {
                        _currentOperation = button.Content.ToString();
                        Display.Text += " " + _currentOperation + " ";
                    }
                    else
                    {
                        MessageBox.Show("Invalid input format");
                    }
                }
            }
        }

        private void EqualsButton_Click(object sender, RoutedEventArgs e)
        {
            // Break down calculation string into value, operator, value
            string[] parts = Display.Text.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length < 3) return;

            //if either number is unable to be parsed, show error
            if (!double.TryParse(parts[0], out _storedValue) || !double.TryParse(parts[2], out _currentValue))
            {
                MessageBox.Show("Invalid input format");
                return;
            }

            _currentOperation = parts[1];

            double result = 0;
            switch (_currentOperation)
            {
                //perform calculation based on operator
                case "+":
                    result = _storedValue + _currentValue;
                    break;
                case "-":
                    result = _storedValue - _currentValue;
                    break;
                case "*":
                    result = _storedValue * _currentValue;
                    break;
                case "/":
                    if (_currentValue != 0)
                    {
                        result = _storedValue / _currentValue;
                    }
                    else
                    {
                        MessageBox.Show("Cannot divide by zero");
                        return;
                    }
                    break;
            }
            //display calculation (built as expression) and answer
            CalculationDisplay.Text = $"{_storedValue} {_currentOperation} {_currentValue} =";
            Display.Text = result.ToString("G");
            _storedValue = result;
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            //clear calculation and reset new entry flag
            _currentValue = 0;
            _storedValue = 0;
            _currentOperation = string.Empty;
            Display.Text = "0";
            _isNewEntry = true;
        }

        private void NegateButton_Click(object sender, RoutedEventArgs e)
        {
            //inverts number
            if (double.TryParse(Display.Text, out double value))
            {
                value = -value;
                Display.Text = value.ToString();
            }
        }

        private void BackspaceButton_Click(object sender, RoutedEventArgs e)
        {
            //Removes last char from calculation string
            if (Display.Text.Length > 0)
            {
                Display.Text = Display.Text.Substring(0, Display.Text.Length - 1);
            }
        }

        private void PeriodButton_Click(object sender, RoutedEventArgs e)
        {
            //Insert decimal
            if (_isNewEntry)
            {
                Display.Text = "0.";
                _isNewEntry = false;
            }
            else if (!Display.Text.Contains("."))
            {
                Display.Text += ".";
            }
        }
    }
}
