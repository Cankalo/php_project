﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Text.RegularExpressions;
using System.Diagnostics;
using System.Windows.Threading;
using BetaalsysteemNEW;

namespace Betaalsysteem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string[] fietsen = new string[12];
        double[] prijzen = new double[20];
        string[] verzekeringen = new string[4];
        string[] services = new string[4];
        string[] orders = Array.Empty<string>();
        double totalPrice;

        private DispatcherTimer timeoutTimer;
        private int tickCounter;

        public MainWindow()
        {
            InitializeComponent();

            // Initialize Timer
            timeoutTimer = new DispatcherTimer();
            timeoutTimer.Interval = TimeSpan.FromSeconds(1);
            timeoutTimer.Tick += DispatcherTimer_Tick;

            // Start timer
            timeoutTimer.Start();

            try
            {
                // Initiate Streamreader to read products from CSV file
                using (StreamReader sr = new StreamReader("Data2024\\wpf\\prijzen_fietsen_verzekeringen_services.csv"))
                {
                    string line;
                    int lineNumber = 0;
                    int fietsCounter = 0;
                    int verzekeringCounter = 0;
                    int servicesCounter = 0;
                    // Read and display lines from the file until the end of the file
                    while ((line = sr.ReadLine()) != null)
                    {
                        string trimmedLine = line.Trim('"');
                        string[] values = trimmedLine.Split(";");

                        if (values[0] == "fietsen")
                        {
                            fietsen[fietsCounter] = values[1] + " " + values[2];
                            fietsCounter++;
                        }
                        else if (values[0] == "Verzekeringen")
                        {
                            verzekeringen[verzekeringCounter] = values[1] + " " + values[2];
                            verzekeringCounter++;
                        }
                        else if (values[0] == "Services")
                        {
                            services[servicesCounter] = values[1] + " " + values[2];
                            servicesCounter++;
                        }

                        double extractedPrice = ExtractDoubleFromString(values[2]);
                        prijzen[lineNumber] = extractedPrice;

                        lineNumber++;
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("The file could not be read:");
                Console.WriteLine(e.Message);
                MessageBox.Show("exception");
            }

            cbFietsen.ItemsSource = fietsen;
            cbVerzekeringen.ItemsSource = verzekeringen;
            cbServices.ItemsSource = services;

        }

        private void DispatcherTimer_Tick(object sender, EventArgs e)
        {
            tickCounter++;

            // Update progress bar
            pbTimeout.Value = (tickCounter / 60.0) * 100;

            // Stop timer after 60 seconds
            if (tickCounter >= 60)
            {
                timeoutTimer.Stop();
                // Shutdown Application
                Application.Current.Shutdown();
            }
        }

        private void ResetTimeoutTimer()
        {
            timeoutTimer.Stop();
            tickCounter = 0;
            timeoutTimer.Start();
        }
        private double ExtractDoubleFromString(string input)
        {
            // Regex expression to match a double
            Regex regex = new Regex(@"\d+(\.\d+)?");
            Match match = regex.Match(input);

            if (match.Success)
            {
                // Convert value to double
                return double.Parse(match.Value) / 100;
            }
            else
            {
                throw new FormatException("The input does not contain a valid double");
            }
        }


        // Clear other comboboxes when item is selected
        private void cbFietsen_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ResetTimeoutTimer();
            if (cbFietsen.SelectedIndex != -1)
            {
                cbVerzekeringen.SelectedIndex = -1;
                cbServices.SelectedIndex = -1;
            }
        }

        // Clear other comboboxes when item is selected
        private void cbVerzekeringen_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ResetTimeoutTimer();
            if (cbVerzekeringen.SelectedIndex != -1)
            {
                cbFietsen.SelectedIndex = -1;
                cbServices.SelectedIndex = -1;
            }
        }

        // Clear other comboboxes when item is selected
        private void cbServices_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ResetTimeoutTimer();
            if (cbServices.SelectedIndex != -1)
            {
                cbFietsen.SelectedIndex = -1;
                cbVerzekeringen.SelectedIndex = -1;
            }
        }


        private void daysChanged(object sender, TextChangedEventArgs e)
        {
            ResetTimeoutTimer();
            // Check if the input is a number and not empty
            if (tbDays.Text != "")
            {
                try
                {
                    //Select correct price based on selected item
                    int days = Int32.Parse(tbDays.Text);
                    if (cbFietsen.SelectedIndex > -1)
                    {
                        double price = days * prijzen[cbFietsen.SelectedIndex];
                        tbPrice.Text = price.ToString("F2");
                    }
                    else if (cbVerzekeringen.SelectedIndex > -1)
                    {
                        double price = days * prijzen[cbVerzekeringen.SelectedIndex + 12];
                        tbPrice.Text = price.ToString("F2");
                    }
                    else if (cbServices.SelectedIndex > -1)
                    {
                        double price = days * prijzen[cbServices.SelectedIndex + 16];
                        tbPrice.Text = price.ToString("F2");
                    }
                }

                catch (Exception)
                {
                    MessageBox.Show("Please enter a valid number of days");
                    tbDays.Clear();
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ResetTimeoutTimer();
            string orderLine = string.Empty;

            // Build Order line based on selected item and days
            if (cbFietsen.SelectedIndex > -1)
            {
                orderLine = cbFietsen.SelectedItem.ToString() + " voor " + tbDays.Text + " dagen. Totaal: " + tbPrice.Text + " euro";
                //MessageBox.Show(orderLine);
            }
            else if (cbVerzekeringen.SelectedIndex > -1)
            {
                orderLine = cbVerzekeringen.SelectedItem.ToString() + " voor " + tbDays.Text + " dagen. Totaal: " + tbPrice.Text + " euro";
                //MessageBox.Show(orderLine);
            }
            else if (cbServices.SelectedIndex > -1)
            {
                orderLine = cbServices.SelectedItem.ToString() + " voor " + tbDays.Text + " dagen. Totaal: " + tbPrice.Text + " euro";
                //MessageBox.Show(orderLine);
            }
            else
            {
                MessageBox.Show("Selecteer een product a.u.b");
            }

            // Update Total Price
            totalPrice += double.Parse(tbPrice.Text);
            orders = orders.Append(orderLine).ToArray();
            lbOrderList.ItemsSource = orders;
            tbTotalPrice.Text = totalPrice.ToString("F2");

            // Clear comboboxes and textboxes
            cbFietsen.SelectedIndex = -1;
            cbVerzekeringen.SelectedIndex = -1;
            cbServices.SelectedIndex = -1;
            tbDays.Clear();
            tbPrice.Clear();
        }
        private void lbOrderList_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ResetTimeoutTimer();
            int selectedIndex = lbOrderList.SelectedIndex;
            if (selectedIndex >= 0 && selectedIndex < orders.Length)
            {
                MessageBoxResult deleteConfirm = MessageBox.Show("Are you sure you want to delete this item?", "Delete Item?", MessageBoxButton.YesNo);
                if (deleteConfirm == MessageBoxResult.Yes)
                {
                    // Extract the price from the selected order line
                    string selectedOrder = orders[selectedIndex];
                    string priceString = Regex.Match(selectedOrder, @"Totaal: (\d+([.,]\d+)?) euro").Groups[1].Value;
                    double price = double.Parse(priceString);

                    // Subtract price from totalPrice
                    totalPrice -= price;

                    // Update total price TextBox
                    tbTotalPrice.Text = totalPrice.ToString("F2");

                    // Remove selected order line
                    orders = orders.Where((order, index) => index != selectedIndex).ToArray();
                    lbOrderList.ItemsSource = orders;
                }
            }
        }

        private void btNextCustomer_Click(object sender, RoutedEventArgs e)
        {
            ResetTimeoutTimer();
            if (lbOrderList.Items.Count == 0)
            {
                MessageBox.Show("There are currently no orders");
            }
            else
            {
                MessageBoxResult paidConfirm = MessageBox.Show("Was the order paid for?", "Complete Order?", MessageBoxButton.YesNo);
                if (paidConfirm == MessageBoxResult.Yes)
                {
                    // Clear the order list and reset all values
                    orders = Array.Empty<string>();
                    lbOrderList.ItemsSource = orders;
                    totalPrice = 0;
                    tbTotalPrice.Text = totalPrice.ToString("F2");
                    cbFietsen.SelectedIndex = -1;
                    cbVerzekeringen.SelectedIndex = -1;
                    cbServices.SelectedIndex = -1;
                    tbDays.Clear();
                    tbPrice.Clear();
                    tbTotalGiven.Clear();
                    tbTotalToReturn.Clear();

                    // Clear all textboxes in the grid
                    foreach (UIElement element in gMoneyCounter.Children)
                    {
                        if (element is TextBox textBox)
                        {
                            textBox.Text="0";
                        }
                    }
                }
            }
        }
        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !IsTextAllowed(e.Text);
        }

        private static bool IsTextAllowed(string text)
        {
            Regex regex = new Regex("[^0-9]+"); //regex that matches disallowed text
            return !regex.IsMatch(text);
        }
        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            // cast sender (aka the deselected textbox) to TextBox
            TextBox textBox = sender as TextBox;
            // if the textbox is empty, set it to 0
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = "0";
            }
        }
        private void UpdateTotalGiven(object sender, TextChangedEventArgs e)
        {
            double totalGiven = 0;

            // go trough all children in the grid (that are textboxes) and calculate the total
            foreach (UIElement element in gMoneyCounter.Children)
            {
                if (element is TextBox textBox)
                {
                    double multiplier = 0;

                    switch (textBox.Name)
                    {
                        case "tbFiveCents":
                            multiplier = 0.05;
                            break;
                        case "tbTenCents":
                            multiplier = 0.10;
                            break;
                        case "tbTwentyCents":
                            multiplier = 0.20;
                            break;
                        case "tbFiftyCents":
                            multiplier = 0.50;
                            break;
                        case "tb1Euro":
                            multiplier = 1.00;
                            break;
                        case "tb2Euros":
                            multiplier = 2.00;
                            break;
                        case "tb5Euros":
                            multiplier = 5.00;
                            break;
                        case "tb10Euros":
                            multiplier = 10.00;
                            break;
                        case "tb20Euros":
                            multiplier = 20.00;
                            break;
                        case "tb50Euros":
                            multiplier = 50.00;
                            break;
                        case "tb100Euros":
                            multiplier = 100.00;
                            break;
                        case "tb200Euros":
                            multiplier = 200.00;
                            break;
                    }
                    // parse the value in the textbox, store it in "value" and multiply
                    if (double.TryParse(textBox.Text, out double value))
                    {
                        totalGiven += value * multiplier;
                    }
                }
            }

            if (tbTotalGiven != null)
            {
                // calculate change and update both textboxes
                ResetTimeoutTimer();
                tbTotalGiven.Text = totalGiven.ToString("F2");
                tbTotalToReturn.Text = (totalGiven - totalPrice).ToString("F2");
            }
        }

        private void btCalc_Click(object sender, RoutedEventArgs e)
        {
            ResetTimeoutTimer();
            Calculator calculatorWindow = new Calculator();

            // Uncomment to pause timer while calculator is open
            //timeoutTimer.Stop();
            //calculatorWindow.Closed += (s, args) => timeoutTimer.Start(); // Resume timer when the calculator is closed
            calculatorWindow.Show();
        }

        private void btClock_Click(object sender, RoutedEventArgs e)
        {
            ResetTimeoutTimer();
            Clock clockWindow = new Clock();

            // Uncomment to pause timer while clock is open
            //timeoutTimer.Stop();
            //clockWindow.Closed += (s, args) => timeoutTimer.Start(); // Resume timer when the calculator is closed
            clockWindow.Show();
        }
    }
}